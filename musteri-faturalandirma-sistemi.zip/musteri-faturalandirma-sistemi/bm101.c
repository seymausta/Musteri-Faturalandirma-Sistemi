#include<stdio.h>                     
#include<stdlib.h>       
#include<conio.h>  
          
void hesapekleme();
void hesaparama();
void musterilistesi();
void clrscr();
void hesapsilme1();
void hesaparama2();

struct hesap{
	char ad[50];
	int no;
	double cepno;
	char semt[50];
	char sehir[50];
	char soyad[50];
	int urunkod;
	int urunfiyat;
	int borc;
	int urunsayisi;
}musteri;




void clrscr()
{
	system("@cls||clear");
} 

int  main()
{
	
	clrscr();
	int x;
	int o;
	printf("\n=======================================================================================================\n");
	printf("\n                           MUSTERI FATURALANDIRMA SISTEMI\n\n");
	printf("                     ---------------------------------------------\n");
	
	printf("\n                             1:	YENI HESAP EKLEME\n");
	printf("                             2:	MUSTERI HESABI ARAMA\n");
	printf("                             3:	HESAP SILME\n");
	printf("                             4: MUSTERI LISTESI\n");
	printf("                             5:	CIKIS\n");
	printf("\n========================================================================================================\n");
	
	printf("\n                        Yapmak istediginiz islemi seciniz: ");
	scanf("%d",&x);
	while(x<=0 || x>6)
	{
	printf("\n                     !!!! Hatali islem girdiniz tekrar seciniz:  ");
	scanf("%d",&x);
	}
	switch(x)
	{
		case 1:
			hesapekleme();
			break;
		case 2:
			clrscr();
		printf("      \n\n     ARAMA TURUNU SECINIZ\n\n");
		printf("\n    1 --- Musteri numarasina gore arama\n");
		printf("    2 --- Isme gore arama                  => ");
		scanf("%d",&o);
		if (o==1){ 
		hesaparama();
		}
		else if (o==2){
		hesaparama2();	
		}
	
			break;
		case 3:
			hesapsilme1();
			break;
		case 4:
			musterilistesi();
			break;
			
		case 5:
			clrscr();
			printf("\n\n             ***IYI GUNLER***  \n\n");
			system("pause");
			break;
	}
	
	
	return 0;
}

void hesaparama()
{
	clrscr();
	int y;
	int xno;
	int no;
	double cep;
	char ad[50];
	char smt[50];
	char shr[50];
	char sa[50];
	int sayi;
	int borc;
	
	printf("\n   Aramak istediginiz musterinin numarasini giriniz: ");
	scanf("%d",&xno);
	
	FILE *dp;
	dp = fopen("dosya.txt", "r+");
	if (dp == NULL)
	printf("dosya acilamadi cunki hic musteri yok");
    else{
	  	while(!feof(dp))
	  	{
    	fscanf(dp,"%d%s%s%lf%s%s%d%d",&no,&ad,&sa,&cep,&smt,&shr,&sayi,&borc);
		if(xno==no)
		break;
    }
printf("        \n\n ---------------------------------------------\n");
    printf("\n     Musteri no: %d  \n     Ad        : %s \n     Soyad     : %s \n     Cep       : %.lf \n     Semt      : %s \n     Sehir     : %s \n     Urun sayisi: %d\n     Toplam Alinan Urun Fiyati: %d  \n\n\n\n ",no,ad,sa,cep,smt,shr,sayi,borc);
     printf("        \n ---------------------------------------------\n");       
	}
	fclose(dp);
	printf("\n    Ana menuye donmek icin : 1\n\n    Cikis yapmak icin      : 2\t");
	scanf("%d",&y);
	if(y==1)
	main();
	else if(y==2){
	clrscr();
		printf("\n\n             ***IYI GUNLER***  \n\n");
	system("pause");}
	else
	printf("Hatali secim!");
	
}



int musterino=1;

void hesapekleme()
{
	clrscr();
	int y;
	int i=1;
	int urunsayi;
	

	FILE *dp;
	dp = fopen("dosya.txt", "a+");
	if (dp == NULL)
		printf("dosya acilamadi");
	else {
	printf("\n\n            ##YENI MUSTERI HESABI EKLEME ISLEMI##\n\n");
		printf("         ---------------------------------------------\n");
	printf("\n       Musteri numarasi         : %d\n",musterino);
	fprintf(dp,"%d ",musterino);
	musterino++;
		
	printf("       Musteri adi giriniz      : ");
	scanf("%s",&musteri.ad);
	fprintf(dp, "%s ",musteri.ad);
	
	printf("       Musteri soyadi giriniz   : ");
	scanf("%s",&musteri.soyad);
	fprintf(dp, "%s ",musteri.soyad);
		
	printf("       Cep numarasi giriniz     : ");
	scanf("%lf",&musteri.cepno);
	fprintf(dp, "%lf ",musteri.cepno);
	
	printf("       Semt giriniz             : ");
	scanf("%s",musteri.semt);
	fprintf(dp, "%s ",musteri.semt);
	
	printf("       Sehir giriniz            : ");
	scanf("%s",musteri.sehir);
	fprintf(dp, "%s ",musteri.sehir);		
	
	printf("\n       ---------------------------------------------\n");
	printf("\n\n        Eklenecek urun sayisi giriniz :\t");
	scanf("%d",&urunsayi);

	printf("\n       ---------------------------------------------\n\n");
	printf("        Urun 1 Kodu: 1211       Urun 1 Fiyati(TL):175\n");   
	printf("        Urun 2 Kodu: 1212       Urun 2 Fiyati(TL): 245\n");
	printf("        Urun 3 Kodu: 1213       Urun 3 Fiyati(TL): 623\n");
	printf("        Urun 4 Kodu: 1214       Urun 4 Fiyati(TL):72\n");
	printf("        Urun 5 Kodu: 1215       Urun 5 Fiyati(TL):89\n ");
	printf("\n       ---------------------------------------------\n\n");
	
	musteri.borc=0;
	
	while(i<=urunsayi)
	{

	printf(" \n        Alinan urun kodu giriniz           :\t ");
	scanf("%d",&musteri.urunkod);
	
	
	if(musteri.urunkod==1211)
	musteri.urunfiyat=175;
	else if(musteri.urunkod==1212)
	musteri.urunfiyat=245;
	else if(musteri.urunkod==1213)
	musteri.urunfiyat=623;
	else if(musteri.urunkod==1214)
    musteri.urunfiyat=72;
	else if(musteri.urunkod==1215)
	musteri.urunfiyat=89;
	
	musteri.borc+=musteri.urunfiyat;
	i++;
	}
	musteri.urunsayisi=urunsayi;
	fprintf(dp,"%d ",musteri.urunsayisi);
	fprintf(dp, "%d \n",musteri.borc);
	
		}
	
	printf("\n        ---------------------------------------------\n");
	printf("\n         ***YENI MUSTERI BASARIYLA EKLENMISTIR***\n");
	fclose(dp);
	printf("\n        ---------------------------------------------\n");
	printf("\n          Ana menuye donmek icin : 1\n\n          Cikis yapmak icin      : 2\t");
	scanf("%d",&y);
	if(y==1)
	main();
	else if(y==2){
    clrscr();
		printf("\n\n             ***IYI GUNLER***  \n\n");
	system("pause");}
	else
	printf("Hatali secim!");
}



void musterilistesi()
{
	clrscr();
	printf("\n                HESABI BULUNAN TUM MUSTERILER\n\n");
	printf("          ---------------------------------------------\n");
	int y;
	int no;
	double cep;
	char ad[50];
	char smt[50];
	char shr[50];
	char sa[50];
	int sayi;
	int borc;

	FILE *dp;
	dp = fopen("dosya.txt", "r+");
	if (dp == NULL)
	printf("dosya acilamadi cunki hic musteri yok");
    else{
	  	while(!feof(dp))
	  	{
    	fscanf(dp,"%d%s%s%lf%s%s%d%d",&no,&ad,&sa,&cep,&smt,&shr,&sayi,&borc);
		printf("\n     ~~Musteri no: %d  \n     Ad        : %s \n     Soyad     : %s \n     Cep       : %.lf \n     Semt      : %s \n     Sehir     : %s \n     Urun sayisi: %d\n     Toplam Alinan Urun Fiyati: %d  \n\n\n\n ",no,ad,sa,cep,smt,shr,sayi,borc);
     
    	printf("          ---    ---    ---    ---    ---    ---\n");
	}
    }
	fclose(dp);

	printf("\n     Ana menuye donmek icin : 1\n\n     Cikis yapmak icin      : 2\t");
	scanf("%d",&y);
	if(y==1)
	main();
	else if(y==2){
		 clrscr();
		printf("\n\n             ***IYI GUNLER***  \n\n");
	system("pause");}
	else
	printf("Hatali secim!");
}

void hesapsilme1()
{
	clrscr();
	FILE *dp1, *dp2;
    char ch;
    int satiri_sil;
	int i = 1;
	int y;
 
    dp1 = fopen("dosya.txt", "r");
    ch = getc(dp1);
    	printf("\n\n\n                    HESABI BULUNAN MUSTERILER\n\n");
	printf("              ---------------------------------------------\n");
    while (ch != EOF)
    {
        printf("%c", ch);
        ch = getc(dp1);
    }
    
    rewind(dp1);
    	printf("              ---------------------------------------------\n");
    printf(" \n             Silinecek olan hesap icin musteri num. giriniz : ");
    scanf("%d", &satiri_sil);
   
    dp2 = fopen("replica.txt", "w");
    ch = getc(dp1);
    while (ch != EOF)
    {
        ch = getc(dp1);
        if (ch == '\n')
            i++;
            
            if (i != satiri_sil)
            {
                
                putc(ch, dp2);
            }
    }
    fclose(dp1);
    fclose(dp2);
    remove("dosya.txt");

    rename("replica.txt", "dosya.txt");
    clrscr();
	printf("\n\n                 Guncel kalan musteri hesaplari: \n\n");
    printf("              ---------------------------------------------\n");
    dp1 = fopen("dosya.txt", "r");
    ch = getc(dp1);
    while (ch != EOF)
    {
        printf("%c", ch);
        ch = getc(dp1);
    }
    fclose(dp1);
    	printf("\n Ana menuye donmek icin : 1\n\n Cikis yapmak icin      : 2\t");
	scanf("%d",&y);
	if(y==1)
	main();
	else if(y==2){
	clrscr();
		printf("\n\n             ***IYI GUNLER***  \n\n");
	system("pause");}
	else
	printf("Hatali secim!");
	
}

void hesaparama2()
{
	
	int no;
	char ad[50];
	char soyad[50];
	double cepno;
	char semt[50];
	char sehir[50];
	int borc;
	int urunsayisi;
	
	
	int ptr;
	
	
	int i;
	int y;
	clrscr();
	int o;
	int n;
	int m=1;
	char isim[50];
	FILE *dp;
	dp = fopen("dosya.txt", "r+");
	
	fseek(dp,0, SEEK_END);
		o = ftell(dp);
		
		o/= sizeof(musteri);
		fseek(dp, (o - 1) * sizeof(musteri), SEEK_SET);
		
		fscanf(dp,"%d",&no);
		n = no;

		
			printf("\nIsmi giriniz:");
			scanf("%s", isim);
			fseek(dp, 0, SEEK_SET);
			for (i = 1; i <= n; i++)
			{
			
				fread(&musteri, sizeof(musteri), 1, dp);
			//	fscanf(dp,"%d%s%s%.lf%s%s%d%d",&no,&ad,&soyad,&cepno,&semt,&sehir,&urunsayisi,&borc);
				printf("\n     Musteri no: %d  \n     Ad        : %s \n     Soyad     : %s \n     Cep       : %.lf \n     Semt      : %s \n     Sehir     : %s \n     Urun sayisi: %d\n     Toplam Alinan Urun Fiyati: %d  \n\n\n\n ",musteri.no,musteri.ad,musteri.soyad,musteri.cepno,musteri.semt,musteri.sehir,musteri.urunsayisi,musteri.borc);
				if (strcmp(musteri.ad, isim) == 0)
				{
					printf("\n     Musteri no: %d  \n     Ad        : %s \n     Soyad     : %s \n     Cep       : %.lf \n     Semt      : %s \n     Sehir     : %s \n     Urun sayisi: %d\n     Toplam Alinan Urun Fiyati: %d  \n\n\n\n ",musteri.no,musteri.ad,musteri.soyad,musteri.cepno,musteri.semt,musteri.sehir,musteri.urunsayisi,musteri.borc);
					m = 0;
					break;
				}
			}
			if (m != 0)
				printf("\n\nMusteri bulunamadi\n");
	fclose(dp);
	printf("\n Ana menuye donmek icin : 1\n\n Cikis yapmak icin      : 2\t");
	scanf("%d",&y);
	if(y==1)
	main();
	else if(y==2){
	clrscr();
		printf("\n\n             ***IYI GUNLER***  \n\n");
	system("pause");}
	else
	printf("Hatali secim!");
	
}




